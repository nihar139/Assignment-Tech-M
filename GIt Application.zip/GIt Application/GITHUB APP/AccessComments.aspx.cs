﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.Data;
using Microsoft.Office.Interop.Excel;
using System.ComponentModel;
using System.Reflection;
using System.IO;
using ClosedXML.Excel;

namespace GITHUB_APP
{
    public partial class AccessComments : System.Web.UI.Page
    {
        public class Sortedstringlist
        {
            public string word { get; set; }
            public int countOfWord { get; set; }
        }
      static   List<Sortedstringlist> orderedlist = new List<Sortedstringlist>();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnLogin_Click1(object sender, EventArgs e)
        {
            orderedlist.Clear();

            if (!string.IsNullOrEmpty(txtURL.Text.Trim()))
                {

                List<Sortedstringlist> ordlist = new List<Sortedstringlist>();
                ordlist = getGithubData();
                gvDisplayCommentData.Visible = true;
                btnExportToExcel.Visible = true;
                gvDisplayCommentData.DataSource = ordlist;
                gvDisplayCommentData.DataBind();
            }
            else
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "ShowStatus", "MessageBox('URL is mandatory to fetch comments');", true);
            }
        }

        private List<Sortedstringlist> getGithubData()
        {
            try
            {
                string name = txtUserName.Text;
                string token = txtToken.Text;
                string URL = txtURL.Text.Trim();
                HttpClient client = new HttpClient();
                ServicePointManager.Expect100Continue = true;
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                       | SecurityProtocolType.Tls11
                       | SecurityProtocolType.Tls12
                       | SecurityProtocolType.Ssl3;
                if (!String.IsNullOrEmpty(token))
                {
                    client.DefaultRequestHeaders.Add("Authorization", "token " + token + "");
                }
                client.DefaultRequestHeaders.Add("User-Agent", "Gitapp");

                var content = client.GetStringAsync(URL + "/commits").Result;
                JArray jsonParsedArray = JArray.Parse(content);
                List<string> sha = new List<string>();
                List<string> comments = new List<string>();
                StringBuilder sbcomment = new StringBuilder();
                foreach (var item in jsonParsedArray.Children())
                {
                    var itemProperties = item.Children<JProperty>();

                    var myElement = itemProperties.FirstOrDefault(x => x.Name == "sha");
                    var myElementValue = myElement.Value;
                    sha.Add(myElementValue.ToString());

                }

                foreach (var item in sha)
                {
                    var newcontent = client.GetStringAsync(URL + "/commits/" + item.ToString()).Result;
                    JObject jsonparsedcomments = JObject.Parse(newcontent);
                    var itemProperties = jsonparsedcomments.Children<JProperty>();
                    var myElement = itemProperties.FirstOrDefault(x => x.Name == "commit");
                    JObject jsonmyElement = JObject.Parse(myElement.Value.ToString());
                    var itemcomProperties = jsonmyElement.Children<JProperty>();
                    var myElementValue = itemcomProperties.FirstOrDefault(x => x.Name == "message").Value;
                    comments.Add(myElementValue.ToString());
                    sbcomment.Append(myElementValue.ToString());
                }
                String[] strarray = sbcomment.ToString().Split(' ');
                orderedlist.Clear();
                printInSortedOrder(strarray);
                foreach (var item in orderedlist)
                {
                    int count = 0;
                    for (int i = 0; i < strarray.Length; i++)
                    {
                        if (item.word.Equals(strarray[i].ToString()))
                        {
                            count++;
                        }
                    }
                    if (count > 1)
                    {
                        item.countOfWord = count;
                    }
                }
               
            }
            catch (Exception ex)
            {
                orderedlist.Clear();
                ScriptManager.RegisterStartupScript(this, this.GetType(), "ShowStatus", "MessageBox('some error occured while fetching data');", true);
                //throw ex;
                
            }
            finally
            {

            }
            List<Sortedstringlist> ordnewlist = new List<Sortedstringlist>();
            ordnewlist= orderedlist.Distinct(new Comparer()).ToList();          
            return ordnewlist;
        }
       public class Comparer : IEqualityComparer<Sortedstringlist>
        {
            public bool Equals(Sortedstringlist x, Sortedstringlist y)
            {
                return x.word == y.word;
            }


            public int GetHashCode(Sortedstringlist obj)
            {
                return obj.word.GetHashCode(); // hashcode of variable to compare
            }
        }

        protected void btnexport_Click1(object sender, EventArgs e)
        {
            try
            {
                orderedlist.Clear();
                List<Sortedstringlist> newordlist = new List<Sortedstringlist>();
                newordlist = getGithubData();
                if (newordlist.Count > 0)
                {
                    System.Data.DataTable dt = ConvertToDataTable(newordlist);
                    ExportExcel(dt);
                }
            }
            catch
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "ShowStatus", "MessageBox('Some error occured while Downloading');", true);

            }
        }
        public class Trie
        {
            public Node rootNode;
            public Trie()
            {
                rootNode = null;
            }
            public void insert(String key, int index)
            {
                if (rootNode == null)
                {
                    rootNode = new Node();
                }

                Node currentNode = rootNode;

                for (int i = 0; i < key.Length; i++)
                {
                    char keyChar = key[i];

                    if (currentNode.getChild(keyChar) == null)
                    {
                        currentNode.addChild(keyChar);
                    }

                    currentNode = currentNode.getChild(keyChar);
                }
                currentNode.addIndex(index);
            }

            public void traversePreorder(String[] array)
            {
                traversePreorder(rootNode, array);
            }

            public void traversePreorder(Node node, String[] array)
            {

                if (node == null)
                {
                    return;
                }
                if (node.getIndices().Count > 0)
                {
                    foreach (int index in node.getIndices())
                    {
                        Sortedstringlist ssl = new Sortedstringlist();
                        ssl.word = array[index].ToString();
                        ssl.countOfWord = 1;
                        orderedlist.Add(ssl);

                    }
                }
                for (char index = '\n'; index <= '~'; index++)
                {
                    traversePreorder(node.getChild(index), array);
                }
            }

            public class Node
            {
                public Node[] children;
                public List<int> indices;
                public Node()
                {
                    children = new Node[117];
                    indices = new List<int>(0);
                }

                public Node getChild(char index)
                {
                    if (index < '\n' || index > '~')
                    {
                        return null;
                    }
                    return children[index - '\n'];
                }
                public void addChild(char index)
                {
                    if (index < '\n' || index > '~')
                    {
                        return;
                    }

                    Node node = new Node();
                    children[index - '\n'] = node;
                }

                public List<int> getIndices()
                {
                    return indices;
                }

                public void addIndex(int index)
                {
                    indices.Add(index);
                }
            }
        }
       

        public void printInSortedOrder(String[] array)
        {
            Trie trie = new Trie();

            for (int i = 0; i < array.Length; i++)
            {
                trie.insert(array[i], i);
            }

            trie.traversePreorder(array);
        }

        protected void gvDisplayCommentData_RowDataBound(object sender, GridViewRowEventArgs e)
        {
        }

        static System.Data.DataTable ConvertToDataTable<T>(List<T> models)
        {
            // creating a data table instance and typed it as our incoming model   
            // as I make it generic, if you want, you can make it the model typed you want.  
            System.Data.DataTable dataTable = new System.Data.DataTable(typeof(T).Name);

            //Get all the properties of that model  
            PropertyInfo[] Props = typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance);

            // Loop through all the properties              
            // Adding Column name to our datatable  
            foreach (PropertyInfo prop in Props)
            {
                //Setting column names as Property names    
                dataTable.Columns.Add(prop.Name);
            }
            // Adding Row and its value to our dataTable  
            foreach (T item in models)
            {
                var values = new object[Props.Length];
                for (int i = 0; i < Props.Length; i++)
                {
                    //inserting property values to datatable rows    
                    values[i] = Props[i].GetValue(item, null);
                }
                // Finally add value to datatable    
                dataTable.Rows.Add(values);
            }
            return dataTable;
        }

        protected void ExportExcel(System.Data.DataTable dt)
        {
            int a = 0;

            ClosedXML.Excel.XLWorkbook wbook = new ClosedXML.Excel.XLWorkbook();
            wbook.Worksheets.Add(dt, "Sortedstringlist");
            // Prepare the response
            HttpResponse httpResponse = Response;
            httpResponse.Clear();
            httpResponse.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
            //Provide you file name here
            httpResponse.AddHeader("content-disposition", "attachment;filename=\"CommentFile.xlsx\"");

            // Flush the workbook to the Response.OutputStream
            using (MemoryStream memoryStream = new MemoryStream())
            {
                wbook.SaveAs(memoryStream);
                memoryStream.WriteTo(httpResponse.OutputStream);
                memoryStream.Close();
            }

            //httpResponse.End();
        }
    }
}