﻿/* IPD
*
* @type Object
* @description $.IPD is the main object for the template's app.
*              It's used for implementing functions and options related
*              to the template. Keeping everything wrapped in an object
*              prevents conflict with other plugins and is a better
*              way to organize our code.
*/
$.IPD = {};
/* ------------------
* - Implementation -
* ------------------
*/
$(function () {
    //Set up the object
    _init();
    // $.IPD.initClock.startClock();
    $.IPD.SidebarMenuHandler.sidebarMenu();
    $.IPD.SidebarMenuHandler.sidebarToggler();
    $.IPD.GoToTop.handleGoTop();
    $.IPD.layoutOptions.initTooltip();
    //    var analogclock = new analogClock();
    //    window.setInterval(function () {

    //        analogclock.run();

    //    }, 1000);
});
/* ----------------------------------
* - Initialize the IPD Object -
* ----------------------------------
* All IPD functions are implemented below.
*/
function _init() {

    $.IPD.GoToTop = {

        // Handles the go to top button at the footer
        handleGoTop: function () {
            var offset = 300;
            var duration = 500;
            // var the = $(this);
            $(window).scroll(function () {
                if ($(this).scrollTop() > offset) {
                    $('.go-to-top').fadeIn(duration);
                } else {
                    $('.go-to-top').fadeOut(duration);
                }
            });
            $('.go-to-top').click(function (e) {
                e.preventDefault();
                $('html, body').animate({
                    scrollTop: 0
                }, duration);
                return false;
            });
        }
    };
    // Handle sidebar menu
    $.IPD.SidebarMenuHandler = {
        sidebarMenu: function () {
            if ($.cookie && $.cookie('activeURL') === $(location).attr('href').split('/')[4]) {
                var activeURL = $.cookie('activeURL');
                var el = $("[href='" + activeURL + "']");
                el.parents('li').each(function () {
                    $(this).addClass('active');
                    $(this).find('> a > span.arrow').addClass('open');

                    if ($(this).parent('ul.sidebar-menu').size() === 1) {
                        $(this).find('> a').append('<span class="selected"></span>');
                    }

                    if ($(this).children('ul.sub-menu').size() === 1) {
                        $(this).addClass('open');
                    }
                });
            }
            $('.sidebar').on('click', 'li > a', function (e) {
                if ($.IPD.WindowSize.getWindowDimension().width >= $.IPD.ScreenSizes.screenSizes('md') && $(this).parents('.sidebar-menu-hover-submenu').size() === 1) { // exit of hover sidebar menu
                    $.IPD.SidebarMenuHandler.setActiveState($(this));
                    return;
                }

                if ($(this).next().hasClass('sub-menu') === false) {
                    if ($.IPD.WindowSize.getWindowDimension().width < $.IPD.ScreenSizes.screenSizes('md') && $('.sidebar').hasClass("in")) { // close the menu on mobile view while laoding a page 
                        $.IPD.SidebarMenuHandler.setActiveState($(this));
                        $('.header .responsive-toggler').click();
                    }
                    return;
                }

                if ($(this).next().hasClass('sub-menu always-open')) {
                    $.IPD.SidebarMenuHandler.setActiveState($(this));
                    return;
                }

                var parent = $(this).parent().parent();
                var the = $(this);
                var menu = $('.sidebar-menu');
                var sub = $(this).next();

                var autoScroll = menu.data("auto-scroll");
                var slideSpeed = parseInt(menu.data("slide-speed"));
                var keepExpand = menu.data("keep-expanded");

                if (keepExpand !== true) {
                    parent.children('li.open').children('a').children('.arrow').removeClass('open');
                    parent.children('li.open').children('.sub-menu:not(.always-open)').slideUp(slideSpeed);
                    parent.children('li.open').removeClass('open');
                }

                var slideOffeset = -200;

                if (sub.is(":visible")) {
                    $('.arrow', $(this)).removeClass("open");
                    $(this).parent().removeClass("open");
                    sub.slideUp(slideSpeed, function () {
                        if (autoScroll === true && $('body').hasClass('sidebar-closed') === false) {
                            $.IPD.Scroller.scrollTo(the, slideOffeset);
                        }
                    });
                } else {
                    $('.arrow', $(this)).addClass("open");
                    $(this).parent().addClass("open");
                    sub.slideDown(slideSpeed, function () {
                        if (autoScroll === true && $('body').hasClass('sidebar-closed') === false) {
                            $.IPD.Scroller.scrollTo(the, slideOffeset);
                        }
                    });
                }

                e.preventDefault();
            });
        },
        // Hanles sidebar toggler
        sidebarToggler: function () {
            var body = $('body');
            if ($.cookie && $.cookie('sidebar_closed') === '1' && $.IPD.WindowSize.getWindowDimension().width >= $.IPD.ScreenSizes.screenSizes('md')) {
                $('body').addClass('sidebar-closed');
                $('.sidebar-menu').addClass('sidebar-menu-closed');
                $('#menu-trigger').removeClass('open');
            }

            // handle sidebar show/hide
            $('body').on('click', '.sidebar-toggler', function (e) {
                var sidebar = $('.sidebar');
                var sidebarMenu = $('.sidebar-menu');
                var menuToggler = $(this);
                if (body.hasClass("sidebar-closed")) {
                    body.removeClass("sidebar-closed");
                    sidebarMenu.removeClass("sidebar-menu-closed");
                    menuToggler.addClass('open');
                    if ($.cookie) {
                        $.cookie('sidebar_closed', '0');
                    }
                } else {
                    body.addClass("sidebar-closed");
                    sidebarMenu.addClass("sidebar-menu-closed");
                    menuToggler.removeClass('open');
                    if ($.cookie) {
                        $.cookie('sidebar_closed', '1');
                    }
                }

                $(window).trigger('resize');
            });

        },

        setActiveState: function (el) {
            var menu = $('.sidebar-menu');
            var linkURL = el.attr('href');
            if (!el || el.size() == 0) {
                return;
            }

            if (linkURL.toLowerCase() === 'javascript:;' || linkURL.toLowerCase() === '#') {
                return;
            }

            // disable active states
            menu.find('li.active').removeClass('active');
            menu.find('li > a > .selected').remove();

            if (menu.hasClass('sidebar-menu-hover-submenu') === false) {
                menu.find('li.open').each(function () {
                    if ($(this).children('.sub-menu').size() === 0) {
                        $(this).removeClass('open');
                        $(this).find('> a > .arrow.open').removeClass('open');
                    }
                });
            } else {
                menu.find('li.open').removeClass('open');
            }

            el.parents('li').each(function () {
                $(this).addClass('active');
                $(this).find('> a > span.arrow').addClass('open');

                if ($(this).parent('ul.sidebar-menu').size() === 1) {
                    $(this).find('> a').append('<span class="selected"></span>');
                }

                if ($(this).children('ul.sub-menu').size() === 1) {
                    $(this).addClass('open');
                }
                if ($.cookie) {
                    $.cookie('activeURL', linkURL);
                }
            });

        }
    };

    $.IPD.WindowSize = {
        getWindowDimension: function () {
            var e = window,
                a = 'inner';
            if (!('innerWidth' in window)) {
                a = 'client';
                e = document.documentElement || document.body;
            }

            return {
                width: e[a + 'Width'],
                height: e[a + 'Height']
            };
        }
    };
    $.IPD.ScreenSizes = {
        screenSizes: function (size) {
            // bootstrap screen sizes
            var sizes = {
                'xs': 480,     // extra small
                'sm': 768,     // small
                'md': 991,     // medium
                'lg': 1200     // large
            };

            return sizes[size] ? sizes[size] : 0;
        }
    };
    $.IPD.layoutOptions = {
        initTooltip: function () {
            $('[data-toggle="tooltip"]').tooltip();
        }
    };
    $.IPD.Scroller = {

        //scroll to top
        scrollTo: function (el, offeset) {
            var pos = (el && el.size() > 0) ? el.offset().top : 0;

            if (el) {
                if ($('body').hasClass('header-fixed')) {
                    pos = pos - $('.header').height();
                }
                pos = pos + (offeset ? offeset : -1 * el.height());
            }

            $('html,body').animate({
                scrollTop: pos
            }, 'slow');
        },
        // function to scroll to the top
        scrollTop: function () {
            scrollTo();
        }
    };

}
//function analogClock() {
//}
//analogClock.prototype.run = function () {
//    var date = new Date();
//    var second = date.getSeconds() * 6;
//    var minute = date.getMinutes() * 6 + second / 60;
//    var hour = ((date.getHours() % 12) / 12) * 360 + 90 + minute / 12;
//    jQuery('#hour').css("transform", "rotate(" + hour + "deg)");
//    jQuery('#minute').css("transform", "rotate(" + minute + "deg)");
//    jQuery('#second').css("transform", "rotate(" + second + "deg)");

//};

